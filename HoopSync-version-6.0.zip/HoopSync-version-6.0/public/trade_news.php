<?php
// Database connection settings
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "WebsiteDB";

// Create connection
$conn = new mysqli($servername, $username, $password, "", $dbname);

// Check if connection was successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch trade news data
$sql = "SELECT * FROM trade_news_item ORDER BY PostDate DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NBA Trade News</title>
    <style>
        /* Basic CSS for table styling */
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f8f9fa;
        }
        h1 {
            text-align: center;
            color: #333;
        }
        .content {
            width: 80%;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            text-align: left;
            border: 1px solid #ddd;
        }
        th {
            background-color: #4CAF50;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        tr:hover {
            background-color: #ddd;
        }
    </style>
</head>
<body>

<header>
    <h1>NBA Trade News</h1>
</header>

<div class="content">
    <h2>Latest Trade News</h2>

    <table>
        <thead>
        <tr>
            <th>NewsID</th>
            <th>Headline</th>
            <th>Post Date</th>
        </tr>
        </thead>
        <tbody>
        <?php
        if ($result->num_rows > 0) {
            // Display each row from the database
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                            <td>{$row['NewsID']}</td>
                            <td>{$row['Headline']}</td>
                            <td>{$row['PostDate']}</td>
                          </tr>";
            }
        } else {
            echo "<tr><td colspan='3'>No trade news found</td></tr>";
        }
        ?>
        </tbody>
    </table>
</div>

</body>
</html>

<?php
// Close the database connection
$conn->close();
?>

