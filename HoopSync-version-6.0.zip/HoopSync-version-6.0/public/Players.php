<?php
include 'Database.php';

$sql = "SELECT * FROM players";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NBA Players</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid black;
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #333;
            color: white;
        }
    </style>
</head>
<body>

<h2>NBA Players List</h2>
<table>
    <tr>
        <th>Name</th>
        <th>Position</th>
        <th>Height (cm)</th>
        <th>Weight (kg)</th>
        <th>Nationality</th>
        <th>Date of Birth</th>
        <th>Draft Year</th>
        <th>Draft Pick</th>
    </tr>

    <?php
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo "<tr>
                        <td>" . $row['name'] . "</td>
                        <td>" . $row['position'] . "</td>
                        <td>" . $row['height_cm'] . "</td>
                        <td>" . $row['weight_kg'] . "</td>
                        <td>" . $row['nationality'] . "</td>
                        <td>" . $row['date_of_birth'] . "</td>
                        <td>" . $row['draft_year'] . "</td>
                        <td>" . $row['draft_pick'] . "</td>
                      </tr>";
        }
    } else {
        echo "<tr><td colspan='8'>No players found</td></tr>";
    }
    $conn->close();
    ?>

</table>

</body>
</html>

