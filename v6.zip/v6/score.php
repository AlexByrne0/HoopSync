<?php
// Include the header template
include('public/templates/header.php');
require_once 'src/DBconnect.php';  // Ensure correct path
include 'game.php';      // Include Game class

// Team ID to display games for (this could be dynamic, set to 3 as an example)
$team_id = 3; 

echo "<h2>Games for Team: $team_id</h2>"; // Display team title

// Initialize the Game object
$game = new Game($connection);

// Query games for the specified team (home or away)
$query = "
    SELECT 
        g.game_id, g.home_team_id, g.away_team_id, g.game_date, g.home_score, g.away_score,
        t1.location AS home_team_name, t2.location AS away_team_name
    FROM games g
    JOIN teams t1 ON g.home_team_id = t1.team_id
    JOIN teams t2 ON g.away_team_id = t2.team_id
    WHERE g.home_team_id = :team_id OR g.away_team_id = :team_id
    ORDER BY g.game_date DESC
";

$stmt = $connection->prepare($query);
$stmt->bindParam(':team_id', $team_id, PDO::PARAM_INT);
$stmt->execute();

// Fetch games
$games = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Display games if available
if ($games) {
    foreach ($games as $game_data) {
        // Set the game properties
        $game->setProperties(
            $game_data['game_id'], 
            $game_data['home_team_id'], 
            $game_data['away_team_id'], 
            $game_data['game_date'], 
            $game_data['home_score'], 
            $game_data['away_score']
        );

        // Output the game details manually
        echo "<h3>" . $game_data['home_team_name'] . " vs " . $game_data['away_team_name'] . "</h3>";
        echo "<p>Game ID: " . $game_data['game_id'] . "</p>";
        echo "<p>Date: " . $game_data['game_date'] . "</p>";
        echo "<p>Score: " . $game_data['home_score'] . " - " . $game_data['away_score'] . "</p>";
        echo "<hr>";  // Add a separator for each game
    }
} else {
    echo "<p>No games found for this team.</p>"; // No games message
}

// Include the footer template
include('public/templates/footer.php');
?>
