<?php
class Game {
    private $connection;
    private $game_id;
    private $home_team_id;
    private $away_team_id;
    private $game_date;
    private $home_score;
    private $away_score;

    // Constructor to initialize the database connection
    public function __construct($connection) {
        $this->connection = $connection;
    }

    // Set game properties
    public function setProperties($game_id, $home_team_id, $away_team_id, $game_date, $home_score, $away_score) {
        $this->game_id = $game_id;
        $this->home_team_id = $home_team_id;
        $this->away_team_id = $away_team_id;
        $this->game_date = $game_date;
        $this->home_score = $home_score;
        $this->away_score = $away_score;
    }

    // Fetch recent scores with team names
    public function getRecentScores() {
        try {
            $query = "
                SELECT 
                    CONCAT(t1.location, ' vs ', t2.location) AS teams, 
                    g.home_score, g.away_score, g.game_date 
                FROM Games g
                JOIN Teams t1 ON g.home_team_id = t1.team_id
                JOIN Teams t2 ON g.away_team_id = t2.team_id
                WHERE g.game_date <= CURDATE()
                ORDER BY g.game_date DESC
                LIMIT 3
            ";
            $stmt = $this->connection->prepare($query);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            die("Error fetching recent games: " . $e->getMessage());
        }
    }

    // Fetch upcoming games with team names
    public function getUpcomingGames() {
        try {
            $query = "
                SELECT 
                    CONCAT(t1.location, ' vs ', t2.location) AS teams, 
                    g.game_date 
                FROM Games g
                JOIN Teams t1 ON g.home_team_id = t1.team_id
                JOIN Teams t2 ON g.away_team_id = t2.team_id
                WHERE g.game_date >= CURDATE()
                ORDER BY g.game_date ASC
                LIMIT 3
            ";
            $stmt = $this->connection->prepare($query);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            die("Error fetching upcoming games: " . $e->getMessage());
        }
    }
}
?>
