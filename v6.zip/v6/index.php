<?php
// Include the database connection file
require_once 'src/DBconnect.php';  // Ensure correct path

// Include the Game class
require_once 'game.php';  // Ensure correct path

// Instantiate the Game class
$game = new Game($connection);

// Fetch recent games
$recentScores = $game->getRecentScores();

// Fetch upcoming games
$upcomingGames = $game->getUpcomingGames();

// Include the header template
include('public/templates/header.php');
?>

<!-- Main Content -->
<div class="content">
    <!-- Display recent NBA scores -->
    <h2>Recent NBA Scores</h2>
    <div class="box">
        <?php foreach ($recentScores as $score) { ?>
            <p><?php echo $score['teams'] . " - " . $score['home_score'] . " : " . $score['away_score'] . " on " . $score['game_date']; ?></p>
        <?php } ?>
    </div>

    <!-- Display upcoming NBA games -->
    <h2>Upcoming NBA Games</h2>
    <div class="box">
        <?php foreach ($upcomingGames as $game) { ?>
            <p><?php echo $game['teams'] . " on " . $game['game_date']; ?></p>
        <?php } ?>
    </div>

    <!-- User Profile Form -->
    <h2>Your NBA Profile</h2>
    <div class="box">
        <form action="profile_submit.php" method="POST">
            <label for="fav_team">Favorite NBA Team:</label><br>
            <input type="text" id="fav_team" name="fav_team" placeholder="Enter your favorite team"><br><br>
            
            <label for="fav_player">Favorite NBA Player:</label><br>
            <input type="text" id="fav_player" name="fav_player" placeholder="Enter your favorite player"><br><br>
            
            <label for="fav_moment">Favorite NBA Moment:</label><br>
            <textarea id="fav_moment" name="fav_moment" rows="4" cols="50" placeholder="Share your favorite NBA moment"></textarea><br><br>
            
            <input type="submit" value="Save Profile">
        </form>
    </div>
</div>

<?php
// Include the footer template
include('public/templates/footer.php');
?>
