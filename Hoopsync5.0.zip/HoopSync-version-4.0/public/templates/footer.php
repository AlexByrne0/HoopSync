<style>.footer{
    position: fixed;
    left 0;
    bottom 0;
    width 100%;
    background-color: green;
    text-align: center};</style>
<footer>
    <p>© 2025 HoopSync. All rights reserved.</p>
</footer>
</body>
</html>
