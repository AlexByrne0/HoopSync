<?php
$site_title = "Contact Us";
$button_text = "Send";
$action_url = "contact.php"; 

//header file
include 'templates/header.php';
?>

<!-- stylesheet -->
<link rel="stylesheet" href="css/infostyle.css">

<div class="container">
    <h2><?php echo $site_title; ?></h2>
    
    <!-- Contact form -->
    <form action="<?php echo $action_url; ?>" method="POST">
        <!-- Name field -->
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required>

        <!-- Email field -->
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>

        <!-- message field -->
        <label for="message">Message:</label>
        <textarea id="message" name="message" rows="4" required></textarea>

        <!-- submit -->
        <button type="submit"><?php echo $button_text; ?></button>
    </form>
</div>

<?php 
// Include the footer file
include 'templates/footer.php'; 
?>
