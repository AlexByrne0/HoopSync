<!-- Code Written by Aleksander Byrne B00164140 with resouces from "Build a no-frills PHP CRUD App with routing-part1" -->
<?php include "templates/header.php"; ?>

<form method="post">
    <label for="firstname">First Name</label>
    <input type="text" name="firstname" id="firstname" required>

    <label for="lastname">Last Name</label>
    <input type="text" name="lastname" id="lastname" required>

    <label for="email">Email Address</label>
    <input type="email" name="email" id="email" required>

    <label for="age">Age</label>
    <input type="text" name="age" id="age">

    <label for="location">Favorite Team</label>
    <input type="text" name="Favorite Team" id="Favteam">

    <label for="location">Least Favoirte Team</label>
    <input type="text" name="Least Favorite Team" id="LFavteam">

    <label for="location">Article</label>
    <input type="text" name="Article" id="Article">


    <input type="submit" name="submit" value="Submit">

</form>
<a href="demowebsite.php">Back to home</a>



    
