<?php include "templates/header.php";?>
<h2>Find Articles</h2>
<form method="post">
<label for="Article"><Article></Article></label>
<input type="text" id="Article" name="Article">
<input type="submit" name="submit" value="View Results">
</form>
<a href="demowebsite.php">Back to home</a>
<?php include "templates/footer.php";?>
